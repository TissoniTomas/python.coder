from setuptools import setup, find_packages

setup(
    name='mi_paquete_cliente',
    version='0.1',
    packages=find_packages(),
    description='Paquete para manejar clientes en una página de compras',
    author='Tu Nombre',
    author_email='tu_correo@ejemplo.com',
)
